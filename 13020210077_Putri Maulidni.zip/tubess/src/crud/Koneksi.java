package crud;

import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;


public class Koneksi {
    public static Connection koneksi() {
        try {
            String url = "jdbc:mysql://localhost/data_karyawan"; 
            String username = "root";
            String password = ""; 
            
            Class.forName("com.mysql.jdbc.Driver");
            Connection koneksi = DriverManager.getConnection(url, username, password);
            
            return koneksi;
        } catch(Exception e) {
            JOptionPane.showMessageDialog(null, e);
            return null;
        }
    }   
}
